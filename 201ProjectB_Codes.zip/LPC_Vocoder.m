clear all;
close all;
[x, fs] =audioread('News_RT1.wav');                          
M=10;  %order of LPC

%GETTING THE PARAMETERS FROM ENCODER
[aCoeff, pitch_plot, voiced, gain] = lpc_encoder(x, fs, M);  %pitch_plot is pitch periods

%SYNTHESIZING THE SPEECH USING ENCODER PARAMETERS
synth_speech = lpc_decoder (aCoeff, pitch_plot, voiced, gain);

%PLAYING THE TWO SIGNALS
% disp('Press a key to play the original file');
% pause;
% sound(x, fs);
disp('Press a button to play the LPC synthesised file');
pause;
sound(synth_speech, fs);

%GENERATING TIME DOMAIN
figure (1);
subplot(211) 
plot(x); 
title('Original Signal'); 
subplot(212) 
plot(synth_speech); 
title('Synthesised signal');


%GENERATING SPECTROGRAM
window=kaiser(1200,5.48);
nooverlap=1000;
nfft=1024;
[s1,f1,t1,p1] = spectrogram(x, window, nooverlap, nfft, fs, 'yaxis');
[s2,f2,t2,p2] = spectrogram(synth_speech, window, nooverlap, nfft, fs, 'yaxis');
figure (2)
subplot(211)
imagesc(10*log10(abs(s1)));
colorbar;
xlabel( 'time (ms)' ); 
ylabel( 'frequency (*10 kHz)' );
title('Spectrogram of Original Signal')
axis xy;
subplot(212)
imagesc(10*log10(abs(s2)));
colorbar;
xlabel( 'time (ms)' ); 
ylabel( 'frequency (*10 kHz)' );
title('Spectrogram of Synthesized Signal')
axis xy;
