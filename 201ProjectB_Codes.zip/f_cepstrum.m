function pitch_period = f_cepstrum(y, fs)


clear pitch_period;
nfft = 1024;

% compute real cepstrum        
        Y_HAT = log(abs(fft(y,nfft)))'; % real cepstrum for one frame length
        y_hat = ifft(Y_HAT,nfft); % cepstrum for one frame length     
        
% defines range for male speech
        ppdMaleLow=round(fs/250); % lower threshold of male voice
        ppdMaleHigh=round(fs/60); % upper threshold of male voice
        indexlow=ppdMaleLow+1;
        indexhigh=ppdMaleHigh+1;
        y_hat_Male = y_hat(indexlow:indexhigh);
        
        
        
%         [R_max , R_mid]=max(y_hat); 
%                       
%         pitch_per_range = y_hat ( R_mid + period_min : R_mid + period_max );
%         [R_max, R_mid] = max(pitch_per_range);
% 
        [pmax,quefrency]= max(y_hat_Male)
         pitch_period = round(1/(fs/quefrency));
        

end