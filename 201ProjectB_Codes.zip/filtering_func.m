function m_s_f = filtering_func(y)

clear m_s_f;

[B,A] = butter(15,0.5,'low'); 
y1 = filter(B,A,y);

m_s_f=sum(abs(y1));