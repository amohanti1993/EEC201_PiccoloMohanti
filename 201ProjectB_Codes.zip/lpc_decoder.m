%DECODER PORTION

function synth_speech = lpc_decoder(aCoeff, pitch_plot, voiced, gain)

frame_length=1;
for i=2:length(gain)
    if gain(i) == 0
        frame_length = frame_length + 1;
    else
        break;
    end
end

for b=1 : frame_length : (length(gain))    
    
    if voiced(b) == 1 
            pitch_plot_b = pitch_plot(b);
        syn_y1 = synthesize_v(aCoeff, gain, frame_length, pitch_plot_b, b);
    else
        syn_y1 = synthesize_uv(aCoeff, gain, frame_length, b);
    end
    
    synth_speech1(b:b+frame_length-1) = syn_y1;
    synth_speech = filter(1, [1 -.9378], synth_speech1); %De-emphasis filter  
end
