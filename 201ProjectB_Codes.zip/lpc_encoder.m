function [aCoeff, pitch_plot, voiced, gain] = lpc_encoder(x, fs, M)

%INITIALIZATION;
b=1;        %index no. of starting data point of current frame
frame_size = 30e-3;    %frame size = 30 ms
frame_length = round(fs .* frame_size);   %=number data points in each framesize of "x"             
N= frame_length - 1;        %N+1 = frame length = number of data points in each framesize
                                
%VOICED/UNVOICED and PITCH DETERMINATION     [independent of frame segmentation]
[voiced, pitch_plot] = v_uv_detection(x, fs, frame_size);

%FRAME SEGMENTATION for LPC COEFFICIENTS and GAIN;
for b=1 : frame_length : (length(x) - frame_length)
    y1=x(b:b+N);     %"y" denotes an array of the data points of the current frame 
                     %"b+N" denotes the end point of current frame.          
    y1 = filter([1 -.9378], 1, y1);  %pre-emphasis filtering
    
    y =y1.* hamming(frame_length);
    %LPC COEFFICIENTS USING LEVINSON-DURBIN RECURSION;
    [a, tcount_of_aCoeff, e] = func_lev_durb (y, M); %e=error signal from lev-durb recusrion
    aCoeff(b: (b + tcount_of_aCoeff - 1)) = a;  %aCoeff is array of "a" for whole "x"
    %GAIN;
        pitch_plot_b = pitch_plot(b); %pitch period
        voiced_b = voiced(b);
        gain(b) = lpc_gain (e, voiced_b, pitch_plot_b);
end