
function pitch_period = pitch_detection(y,fs)
%USING AUTOCORELLATION
clear pitch_period;
min_freq = 80;
max_freq = 300;
period_max = round(fs / min_freq);
period_min = round(fs / max_freq);
frame_len = 2*period_max;
    
%BODY OF PROGRAM
R=xcorr(y);
[R_max , R_mid]=max(R); 
pitch_per_range = R ( R_mid + period_min : R_mid + period_max );
[R_max, R_mid] = max(pitch_per_range);
 pitch_period = R_mid + period_min;