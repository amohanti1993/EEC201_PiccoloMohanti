function syn_y1 = synthesize_v(aCoeff, gain, frame_length, pitch_plot_b, b)

for f=1:frame_length
    if f/pitch_plot_b == floor(f./pitch_plot_b)
        ptrain(f) = 1;
    else 
        ptrain (f) = 0;
    end
end

syn_y2 = filter(1, [1 aCoeff((b+1):(b+1+9))], ptrain);
syn_y1 = syn_y2 .* (gain(b));